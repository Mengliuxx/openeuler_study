/******************************************************************************
* Copyright (c) Huawei Technologies Co., Ltd. 2019. All rights reserved.
* iSulad licensed under the Mulan PSL v2.
* You can use this software according to the terms and conditions of the Mulan PSL v2.
* You may obtain a copy of Mulan PSL v2 at:
*     http://license.coscl.org.cn/MulanPSL2
* THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
* PURPOSE.
* See the Mulan PSL v2 for more details.
* Author: gaohuatao
* Create: 2020-05-14
* Description: isula load operator implement
*******************************************************************************/
#ifndef DAEMON_MODULES_IMAGE_OCI_OCI_LOAD_H
#define DAEMON_MODULES_IMAGE_OCI_OCI_LOAD_H

#include <stddef.h>

#include "image_api.h"
#include "isula_libutils/image_manifest_items.h"
#include "isula_libutils/oci_image_manifest.h"
#include "isula_libutils/oci_image_spec.h"
#include "isula_libutils/json_common.h"
#include "utils_timestamp.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    // uncompressed_digest
    char *diff_id;
    // compressed digest
    char *compressed_digest;
    // with "sha256:" prefix
    char *chain_id;
    char *fpath;
    // layer already exist in storage
    bool alread_exist;
} load_layer_blob_t;

typedef struct {
    load_layer_blob_t **layers;
    size_t layers_len;
    char **repo_tags;
    size_t repo_tags_len;
    char *config_fpath;
    char *im_id;
    char *im_digest;
    char *manifest_fpath;
    char *manifest_digest;
    types_timestamp_t create_time;
    oci_image_manifest *manifest;
    char *layer_of_hold_refs;
} load_image_t;

int oci_do_load(const im_load_request *request);

#ifdef __cplusplus
}
#endif

#endif
